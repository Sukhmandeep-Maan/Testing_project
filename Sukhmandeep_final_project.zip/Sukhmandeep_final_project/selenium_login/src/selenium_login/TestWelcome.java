package selenium_login;

import java.util.concurrent.TimeUnit;

import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.interactions.Actions;

public class TestWelcome {
	public static void main(String[] args) {
		System.setProperty("webdriver.chrome.driver",
				"C:\\Users\\Administrator\\Downloads\\chromedriver-win64\\chromedriver-win64\\chromedriver.exe");
		ChromeOptions options = new ChromeOptions();
		
		WebDriver driver = new ChromeDriver(options);

		// URL of the login website that is tested
        String url = "file:///C:/Users/Administrator/Downloads/welcome-testing-main/welcome-testing-main/gym%20Website/gym%20website.html";
        driver.get(url);
        driver.manage().window().maximize();
        driver.manage().timeouts().pageLoadTimeout(10, TimeUnit.SECONDS);
        
        ///////////////////// PART B ////////////////////
        
        
        
        driver.manage().timeouts().pageLoadTimeout(10,TimeUnit.SECONDS);
        
        WebElement btn1 = driver.findElement(By.id("btn1"));
        WebElement btn2 = driver.findElement(By.id("btn2"));
        WebElement btn3 = driver.findElement(By.id("btn3"));
        
        
        Actions builder = new Actions(driver);
        builder.moveToElement(btn1).perform();
        System.out.println("Checking Join now-button");
        //btn1.click();
        
        builder.moveToElement(btn2).perform();
        System.out.println("Checking Call us now-button");
        
        builder.moveToElement(btn3).perform();
        System.out.println("Checking Email us-button");
        
        String title = "Maan Fitness Club";
        
        String actualTitle = driver.getTitle();
 
        System.out.println("Verifying the page title has started");
        Assert.assertEquals(actualTitle,title);
 
        System.out.println("The page title has been successfully verified");
 
        System.out.println("User logged in successfully");
        
        btn1.click();
        driver.quit();
	}
}
