package selenium_login;

import java.util.concurrent.TimeUnit;

import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.interactions.Actions;

public class TestLogin {
	public static void main(String[] args) {

		// Path of chrome driver
		// that will be local directory path passed
		System.setProperty("webdriver.chrome.driver",
				"C:\\Users\\Administrator\\Downloads\\chromedriver-win64\\chromedriver-win64\\chromedriver.exe");
		ChromeOptions options = new ChromeOptions();
		
		WebDriver driver = new ChromeDriver(options);

		// URL of the login website that is tested
        String url = "file:///C:/Users/Administrator/Downloads/welcome-testing-main/welcome-testing-main/gym%20Website/login.html";
 
        driver.get(url);
        driver.manage().window().maximize();
        driver.manage().timeouts().pageLoadTimeout(10, TimeUnit.SECONDS);
        
        
        
        //////////////        PART B		//////////////////////// 
        
        WebElement login = driver.findElement(By.id("Login"));
      System.out.println("Clicking on the login element in the main page");
      login.click();

      driver.manage().timeouts().pageLoadTimeout(10,TimeUnit.SECONDS);

      WebElement email = driver.findElement(By.id("email"));
      WebElement password = driver.findElement(By.id("password"));
      WebElement login1 = driver.findElement(By.id("Login"));
      Actions builder = new Actions(driver);
      builder.moveToElement(email).perform();
      
      email.clear();
      System.out.println("Entering the email");
      email.sendKeys("sukhmandeep@email.com");
      
      builder.moveToElement(password).perform();
      password.clear();
      System.out.println("entering the password");
      password.sendKeys("password@123");
      
      login1.click();
      
      String title = "Welcome to portal";
      
      String actualTitle = driver.getTitle();

      System.out.println("Verifying the page title has started");
      Assert.assertEquals(actualTitle,title);
      System.out.println("The page title has been successfully verified");
      
      System.out.println("User logged in successfully");

//      driver.quit();
	}
	}
