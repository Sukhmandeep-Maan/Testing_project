package selenium_login;

import org.testng.annotations.Test;
import org.testng.annotations.BeforeMethod;

import java.util.concurrent.TimeUnit;

import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.interactions.Actions;
import org.testng.annotations.AfterMethod;

public class TestNgWelcome {
	WebDriver driver;
  @Test
  public void Button() {
	  WebElement btn1 = driver.findElement(By.id("btn1"));
      WebElement btn2 = driver.findElement(By.id("btn2"));
      WebElement btn3 = driver.findElement(By.id("btn3"));
      
      
      Actions builder = new Actions(driver);
      builder.moveToElement(btn1).perform();
      System.out.println("Checking Join now-button");
      //btn1.click(); 
      
      builder.moveToElement(btn2).perform();
      System.out.println("Checking Call us now-button");
      
      builder.moveToElement(btn3).perform();
      System.out.println("Checking Email us-button");
  }
  
  @Test
  public void Title() {
	  String title = "Maan Fitness Club";
      
      String actualTitle = driver.getTitle();

      System.out.println("Verifying the page title has started");
      Assert.assertEquals(actualTitle,title);

      System.out.println("The page title has been successfully verified");

      
  }
  
  
  @BeforeMethod
  public void beforeMethod() {
	  System.setProperty("webdriver.chrome.driver",
				"C:\\Users\\Administrator\\Downloads\\chromedriver-win64\\chromedriver-win64\\chromedriver.exe");
//		ChromeOptions options = new ChromeOptions();
		
		
		// URL of the login website that is tested
	 driver = new ChromeDriver();
      String url = "file:///C:/Users/Administrator/Downloads/welcome-testing-main/welcome-testing-main/gym%20Website/gym%20website.html";
      driver.get(url);
      
  }

  @AfterMethod
  public void afterMethod() {
	  System.out.println("Closing the browser session");
  	  driver.quit();
  }

}
