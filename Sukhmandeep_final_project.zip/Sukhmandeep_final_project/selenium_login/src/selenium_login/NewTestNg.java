package selenium_login;

import org.testng.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

public class NewTestNg {

  	WebDriver driver;
  	
  @Test
  public void Title() {
  	  //Capturing the title and validating if expected is equal to actual
  	  String expectedTitle = "Welcome to portal";
  	  String actualTitle = driver.getTitle();
  	  Assert.assertEquals(actualTitle, expectedTitle);
  	 System.out.println("The page title has been successfully verified");
    }
 
    @Test 
    public void vales() {

    	WebElement email = driver.findElement(By.id("email"));
        WebElement password = driver.findElement(By.id("password"));
        WebElement repeat_password = driver.findElement(By.id("repeatpassword"));
        WebElement sign_up = driver.findElement(By.id("signup"));
        WebElement cancel = driver.findElement(By.id("cancel"));
        
        Actions builder = new Actions(driver);
        builder.moveToElement(email).perform();
        email.clear();
        System.out.println("Entering the email");
        email.sendKeys("sukhmandeep@email.com");
        
        builder.moveToElement(password).perform();
        password.clear();
        System.out.println("entering the password");
        password.sendKeys("password@123");
        
        System.out.println("repeating password");
        repeat_password.sendKeys("password@123");
    }
    
  @BeforeMethod
  public void beforeMethod() {
  	  System.out.println("Starting the browser session");
  	System.setProperty("webdriver.chrome.driver",
			"C:\\Users\\Administrator\\Downloads\\chromedriver-win64\\chromedriver-win64\\chromedriver.exe");
	 
	//Setting the driver to chrome driver
	  driver = new ChromeDriver();
	  String url = "file:///D:/Signup.html";
	  driver.get(url);
  }
 
  @AfterMethod
  public void afterMethod() {
  	  System.out.println("Closing the browser session");
  	  driver.quit();
  }
}
